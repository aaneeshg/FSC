CREATE SCHEMA `companydb` ;

CREATE TABLE `companydb`.`company` (
  `companycode` VARCHAR(45) NOT NULL,
  `companyname` VARCHAR(45) NULL,
  `companyceo` VARCHAR(45) NULL,
  `companyturnover` INT NULL,
  `companywebsite` VARCHAR(45) NULL,
  `companystockexchange` VARCHAR(45) NULL,
  PRIMARY KEY (`companycode`));
  
  truncate  company;
  
  CREATE TABLE `stockdb`.`stock` (
  `stockid` int NOT NULL,
  `companycode` VARCHAR(45) NULL,
  `stockprice` int NULL,
  `stockdate` DATE NULL,
  PRIMARY KEY (`stockid`));
  
  truncate stock;

alter table stock modify column stockid int NOT NULL AUTO_INCREMENT;

  
 
