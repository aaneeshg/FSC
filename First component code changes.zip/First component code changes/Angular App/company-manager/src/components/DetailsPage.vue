<template>
  <div class="add">
     <div class="row" v-if="priceUpdateFlage">
      <div class="lab"><input type="text"></div>
      <div>
        <button  @click="$emit('cancel')">cancel</button> 
        <button>Save</button>
      </div>
    </div>
    <div class="row">
      <div class="lab">Comapany Name</div>
      <div>CTS</div>
    </div>
    <div class="row">
      <div class="lab">Company Code</div>
      <div>CTS0015</div>
    </div>
    <table id="customers">
      <tr>
        <td>Stock price</td>
        <td>Date</td>
        <td>Time</td>        
      </tr>
      <tr>
        <td>45</td>
        <td>08-12-2021</td>
        <td>12:00:45</td>                
      </tr>
    </table>  
    <div>
      <table id="customers" style="width: 30%;margin-top: 2rem;">
      <tr>
        <td>Maximum</td>
        <td>700</td>        
      </tr>
      <tr>
        <td>Minimum</td>
        <td>320</td>               
      </tr>
      <tr>
        <td>Average</td>
        <td>456</td>               
      </tr>
    </table>
    </div>
     
  </div>
</template>

<script>
export default {
  name: 'DetailsPage',
  props: {
    priceUpdateFlage:{ default: false },
  },
  data () {
    return {
     
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.add {
    padding-top: 1.5rem;
    width: 50%;
    text-align: left;
    margin-left: 20rem;
}
.lab{
  float: left;
  width: 12rem;
}
.row{
  height: 3rem;
}
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}

</style>
