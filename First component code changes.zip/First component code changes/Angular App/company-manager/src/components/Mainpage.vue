<template>
  <div class="hello">
    <div class="head">
      <div class="head-link">
        <div class="link">
          <button class="head-bt" @click="viewManager='AddCompany'">Add Company</button>
          <button class="head-bt" @click="viewManager='ListCompany'">List Company</button>
          <button class="head-bt" v-if="viewManager=='DetailsView'" @click="update=!update">Update Stock Price</button>
        </div>
        <div>
          <input class="head-bt" type="text">
          <button class="head-bt" @click="viewManager='DetailsView'">Search Company</button>
        </div>
      </div>
    </div>
    <div class="body">
      <add-details v-if="viewManager=='AddCompany'" @cancel="viewManager='ListCompany'"></add-details>
      <list-company v-if="viewManager=='ListCompany'"></list-company>
      <details-page @cancel="update=!update" :priceUpdateFlage="update" v-if="viewManager=='DetailsView'"></details-page>
    </div>         
  </div>
</template>

<script>
import AddDetails from "./AddDetails"
import ListCompany from "./ListCompany"
import DetailsPage from "./DetailsPage"


export default {
  name: 'MainPage',
  components: { AddDetails,ListCompany,DetailsPage },
  data () {
    return {
      viewManager : 'ListCompany',
      update:false,
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.head {
  height: 5rem;
  background-color: darkcyan;
}
.head-link {
  padding-top: 1.5rem;
  display: flex;
}
.link {
  width: 50%;
  margin-left: 15rem;
}
.head-bt{
  border-radius: 1rem;
  padding: .5rem;
  cursor: pointer;
}
</style>
