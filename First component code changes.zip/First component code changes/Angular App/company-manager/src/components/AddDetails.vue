<template>
  <div class="add">
    <div class="data-row">
        <div class="lab"><label>Company Name</label></div>
        <input type="text">
    </div>
    <div class="data-row">
        <div class="lab"><label>Company Code</label></div>
        <input type="text">
    </div>
    <div class="data-row">
          <div class="lab"><label>Company CEO</label></div>
        <input type="text">
    </div>
     <div class="data-row">
        <div class="lab"><label>Company Website</label></div>
        <input type="text">
    </div>
    <div class="data-row">
        <div class="lab"><label>Company turnover</label></div>
        <input type="text">
    </div>
    <div class="data-row">
        <div class="lab"><label>Stock Excange</label></div>
        <input type="text">
    </div>
    <div class="data-row">
        <div class="lab"><label>Stock Name</label></div>
        <input type="text">
    </div>
    <div class="data-row">
        <div class="lab"><label>Stock Price</label></div>
        <input type="text">
    </div>
    <div class="action">
        <button class="head-bt" @click="$emit('cancel')">Cancel</button>
        <button class="head-bt" @click="addDetails()">Save</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'AddDetails',
  data () {
    return {
     
    }
  },
  methods: {
      addDetails:function() {
        var self = this;
        var dataVal = {"companyCode":"COM006",
                "companyName":"CTS",
                "companyCEO":"john",
                "companyTurnover":11,
                "companyWebsite":"www.tcs.com",
                "companyStockExchange":"BSF"};   
        var url = 'http://localhost:8085/api/v1.0/market/company/register';
        axios(url, {
            method: 'POST',
            data:dataVal,
            mode: 'no-cors',
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json',
            },
            withCredentials: true,
            credentials: 'same-origin',
        }).then(response => {
              console.log(response);
        }).catch(function (error) {  
            console.log(error);
        }).then(function () {
        });


       /* axios.post(' http://localhost:8085/api/v1.0/market/company/register',data)
        .then(function (response) {    
            console.log(response);
            console.log("data :" ,response.data);
            self.compList = response.data;
            console.log("this.compList : " ,self.compList);
        }).catch(function (error) {  
            console.log(error);
        }).then(function () {
        });*/
      }
  }

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.add {
    padding-top: 1.5rem;
    width: 50%;
    text-align: left;
    margin-left: 20rem;
}
.data-row {
    height: 3rem;
}
.lab {
    width: 12rem;
    float: left;
}
.action {
    text-align: center;
}
.head-bt{
  border-radius: 1rem;
  padding: .5rem;
}
</style>
