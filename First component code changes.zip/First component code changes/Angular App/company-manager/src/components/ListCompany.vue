<template>
  <div class="add">
    <table id="customers">
      <tr>
        <td>Sl.no</td>
        <td>Comapany Name</td>
        <td>CEO</td>
        <td>Website</td>
        <td>turnover</td>
        <td>Stock exeange</td>
        <td>Action</td>
      </tr>
      <tr v-for="(company,index) in compList" :key="index">
        <td>{{index + 1}}</td>
        <td>{{company.companyName}}</td>
        <td>{{company.companyCEO}}</td>
        <td>{{company.companyWebsite}}</td>
        <td>{{company.companyTurnover}}</td>
        <td>{{company.companyStockExchange}}</td>
        <td><a style="cursor: pointer;" @click="deleteCompany(company.companyCode)">Delete</a></td>        
      </tr>
    </table>           
  </div>
</template>

<script>

import axios from 'axios'
export default {
  name: 'ListCompany',
  data () {
    return {
      compList:null
     
    }
  },
  mounted:function() {
    var self = this;
    axios.get('http://localhost:8085/api/v1.0/market/company/getall')
    .then(function (response) {    
      console.log(response);
      console.log("data :" ,response.data);
      self.compList = response.data;
      console.log("this.compList : " ,self.compList);
    })
    .catch(function (error) {  
      console.log(error);
    })
    .then(function () {
    });
  },
  methods:{
    deleteCompany:function(companyCode) {
      let headers = new Headers();
      headers.append('Access-Control-Allow-Origin', 'http://localhost:8081');
      headers.append('Access-Control-Allow-Credentials', true);
      headers.append('Access-Control-Allow-Methods', 'GET, POST,DELETE, OPTIONS');
      headers.append('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept');
      axios.defaults.headers.common['Access-Control-Allow-Origin'] = '*';
      axios.delete('http://localhost:8085/api/v1.0/market/company/delete/'+companyCode)
      .then(function (response) {    
        console.log(response);
        console.log("data :" ,response.data);
        self.compList = response.data;
        console.log("this.compList : " ,self.compList);
      })
      .catch(function (error) {  
        console.log(error);
      })
      .then(function () {
      });
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.add {
    padding-top: 1.5rem;
    width: 50%;
    text-align: left;
    margin-left: 20rem;
}
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}

</style>
