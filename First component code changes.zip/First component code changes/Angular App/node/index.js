const mysql = require('mysql');
const express = require('express');
var app = express();
const bodyparser = require('body-parser');

app.use(bodyparser.json);

var mysqlConnection = mysql.createConnection ({
    host:'127.0.0.1',
    user:'myuser',
    password:'password',
    database:'companydb'
});

mysqlConnection.connect((error)=> {
    if(!error) {
        console.log("Db connection successfulllyyyy");
    }else {
        console.log("Db connection failed : " , JSON.stringify(error,undefined,2));
    }
})

app.listen(3000,()=>
console.log("application running in 3000 port"));

app.get('/company',(req,res)=>
    mysqlConnection.query("select * from company",(err,row,fields)=>{
        if(!err) {
            console.log("row : " , row);            
        }else {
            console.log("err : " , err);            
        }
    })
)
