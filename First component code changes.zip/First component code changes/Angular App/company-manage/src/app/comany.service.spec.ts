import { TestBed } from '@angular/core/testing';

import { ComanyService } from './comany.service';

describe('ComanyService', () => {
  let service: ComanyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ComanyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
