import { Component } from '@angular/core';
import { ComanyService } from './comany.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'company-manage';

  constructor(private companyService : ComanyService){}
  ondeleteTest() {
    this.companyService.registerCompany().subscribe(data=>{
      console.log("get Data :" , data);
    });
    
  }
  onGetTest() {
    this.companyService.getCompany().subscribe(data=>{
      console.log("get Data :" , data);
    });        
  }
}
