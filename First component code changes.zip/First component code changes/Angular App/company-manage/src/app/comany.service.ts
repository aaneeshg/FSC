import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,} from '@angular/common/http';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT',
    'Authorization': 'Bearer szdp79a2kz4wh4frjzuqu4sz6qeth8m3',
  })
};

@Injectable({
  providedIn: 'root'
})
export class ComanyService {

  constructor(private http: HttpClient) { }
  

  deleteCompany(){
    return this.http.delete("http://localhost:8085/api/v1.0/market/company/delete/COM005");
  }
  getCompany(){
    return this.http.get("http://localhost:8085/api/v1.0/market/company/info/COM001");
    //return this.http.get("http://localhost:8765/COMPANY-SERVICES/api/v1.0/market/company/getall");
      //return this.http.get("http://localhost:8092/api/v1.0/market/company/getall");

    
  }
  registerCompany() {
    let obj = {"companyCode":"COM007",
    "companyName":"CTS",
    "companyCEO":"john",
    "companyTurnover":11,
    "companyWebsite":"www.tcs.com",
    "companyStockExchange":"BSF"};

    return this.http.post("http://localhost:8085/api/v1.0/market/company/test",obj,httpOptions);
  }
}
