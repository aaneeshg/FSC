package com.fce.stock.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fce.stock.model.Stock;
import com.fce.stock.services.StockServices;

@RestController
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RequestMapping("/api/v1.0/market/stock")
public class StockRestController {
	@Autowired
	StockServices services;

	@CrossOrigin
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public Stock addcompany(@RequestBody Stock stock) {
		System.out.println("****** : " + stock.getStockId());
		stock.setStockDate(new Date());
		return services.addStock(stock);
	}

	@CrossOrigin
	@RequestMapping(value = "/get/{companycode}/{startdate}/{endDate}", method = RequestMethod.GET)
	public List<Stock> getCompanyDelete(@PathVariable("companycode") String companycode,
			@PathVariable("startdate") String startdate, @PathVariable("enddate") String enddate) {
		return null;
	}

	@CrossOrigin
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public boolean deleteStock(@RequestBody String companycode) {
		System.out.println("*** companycode*** : " + companycode);
		return services.deleteStock(companycode);
	}

}
