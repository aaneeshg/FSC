package com.fce.stock.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fce.stock.model.Stock;
import com.fce.stock.repo.StockRepo;

@Service
public class StockServices {
	
	@Autowired
	StockRepo repo;

	public Stock addStock(Stock stock) {
		return repo.save(stock);
	}

	
	public boolean deleteStock(String companycode) {		
		if(repo.deleteStock(companycode) > 0) {
			return true;
		}else {
			return false;
		}
		
	}

}
