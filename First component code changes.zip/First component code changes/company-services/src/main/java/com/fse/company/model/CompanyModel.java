package com.fse.company.model;

import java.util.List;

public class CompanyModel {

	private String companyCode;
	private String companyName;
	private String companyCEO;
	private int companyTurnover;
	private String companyWebsite;
	private String companyStockExchange;
	private List<Stock> stockList;

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyCEO() {
		return companyCEO;
	}

	public void setCompanyCEO(String companyCEO) {
		this.companyCEO = companyCEO;
	}

	public int getCompanyTurnover() {
		return companyTurnover;
	}

	public void setCompanyTurnover(int companyTurnover) {
		this.companyTurnover = companyTurnover;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}

	public String getCompanyStockExchange() {
		return companyStockExchange;
	}

	public void setCompanyStockExchange(String companyStockExchange) {
		this.companyStockExchange = companyStockExchange;
	}

	public List<Stock> getStockList() {
		return stockList;
	}

	public void setStockList(List<Stock> stockList) {
		this.stockList = stockList;
	}

	@Override
	public String toString() {
		return "CompanyModel [companyCode=" + companyCode + ", companyName=" + companyName + ", companyCEO="
				+ companyCEO + ", companyTurnover=" + companyTurnover + ", companyWebsite=" + companyWebsite
				+ ", companyStockExchange=" + companyStockExchange + ", stockList=" + stockList + "]";
	}

}
