package com.fse.company.model;

import java.util.Date;

public class Stock {
	private int stockId;
	private String companyCode;
	private int stockPrice;
	private Date stockDate;

	public int getStockId() {
		return stockId;
	}

	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public int getStockPrice() {
		return stockPrice;
	}

	public void setStockPrice(int stockPrice) {
		this.stockPrice = stockPrice;
	}

	public Date getStockDate() {
		return stockDate;
	}

	public void setStockDate(Date stockDate) {
		this.stockDate = stockDate;
	}

	@Override
	public String toString() {
		return "Stock [stockId=" + stockId + ", companyCode=" + companyCode + ", stockPrice=" + stockPrice
				+ ", stockDate=" + stockDate + "]";
	}

}
