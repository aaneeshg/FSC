package com.fse.company.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.fse.company.model.Stock;

@FeignClient("STOCK-SERVICES")
public interface StockClient {
	@PostMapping("/api/v1.0/market/stock/add")
	Stock save(@RequestBody Stock stock);

	@DeleteMapping("/api/v1.0/market/stock/delete")
	boolean deleteById(String companycode);
}
