package com.fse.company.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fse.company.client.StockClient;
import com.fse.company.model.Company;
import com.fse.company.model.CompanyModel;
import com.fse.company.model.Stock;
import com.fse.company.services.CompanyServices;

@RestController
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RequestMapping("/api/v1.0/market")
public class CompanyRestController {

	@Autowired
	CompanyServices companyServices;

	@Autowired
	StockClient stockClient;

	@RequestMapping(value = "/company/register", method = RequestMethod.POST)
	public CompanyModel creatCompany(@RequestBody CompanyModel companyMdl) {
		System.out.println("*************** helllo *******************");
		Company saveCompany = companyServices.save(companyMdl);
		Stock stock = new Stock();
		stock.setCompanyCode(saveCompany.getCompanyCode());
		stock.setStockPrice(100);
		Stock saveStock = stockClient.save(stock);
		System.out.println("stock id :" + saveStock.getStockId());
		CompanyModel companyresponse = new CompanyModel();
		companyresponse.setCompanyCEO(saveCompany.getCompanyCEO());
		companyresponse.setCompanyCode(saveCompany.getCompanyCode());
		companyresponse.setCompanyName(saveCompany.getCompanyName());
		companyresponse.setCompanyStockExchange(saveCompany.getCompanyStockExchange());
		companyresponse.setCompanyTurnover(saveCompany.getCompanyTurnover());
		companyresponse.setCompanyWebsite(saveCompany.getCompanyWebsite());
		List<Stock> stockList = new ArrayList<Stock>();
		stockList.add(saveStock);
		companyresponse.setStockList(stockList);
		return companyresponse;
	}
	@CrossOrigin
	@RequestMapping(value = "/company/getall", method = RequestMethod.GET)
	public List<CompanyModel> getAllCompany() {
		List<CompanyModel> companyModelList = new ArrayList<CompanyModel>();
		List<Company> findall = companyServices.findall();
		for (Company company : findall) {
			CompanyModel model = new CompanyModel();
			company.setCompanyCEO(company.getCompanyCEO());
			model.setCompanyCode(company.getCompanyCode());
			model.setCompanyName(company.getCompanyName());
			model.setCompanyStockExchange(company.getCompanyStockExchange());
			model.setCompanyTurnover(company.getCompanyTurnover());
			model.setCompanyWebsite(company.getCompanyWebsite());
			// have to add stock details also
			companyModelList.add(model);
		}
		return companyModelList;
	}

	@RequestMapping(value = "/company/info/{companycode}", method = RequestMethod.GET)
	public Company getCompany(@PathVariable("companycode") String companycode) {
		return companyServices.findByCompanyCode(companycode);
	}	
	@RequestMapping(value = "/company/delete/{companycode}", method = RequestMethod.DELETE)
	public boolean getCompanyDelete(@PathVariable("companycode") String companycode) {
		companyServices.deleteById(companycode);
		stockClient.deleteById(companycode);
		return true;
	}
	@RequestMapping(value = "/company/test", method = RequestMethod.POST)
	public String getCompantest(@RequestBody String companyMdl) {				
		return "hello";
	}
}
