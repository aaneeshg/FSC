package com.fse.company.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fse.company.model.Company;
import com.fse.company.model.CompanyModel;
import com.fse.company.repo.CompanyRepo;

@Service
public class CompanyServices {
	@Autowired
	CompanyRepo companyRepo;

	public Company save(CompanyModel companyMdl) {
		Company company = new Company();
		company.setCompanyCEO(companyMdl.getCompanyCEO());
		company.setCompanyCode(companyMdl.getCompanyCode());
		company.setCompanyName(companyMdl.getCompanyName());
		company.setCompanyStockExchange(companyMdl.getCompanyStockExchange());
		company.setCompanyTurnover(companyMdl.getCompanyTurnover());
		company.setCompanyWebsite(companyMdl.getCompanyWebsite());
		return companyRepo.save(company);
	}

	public List<Company> findall() {		
		return companyRepo.findAll();
	}

	public Company findByCompanyCode(String companycode) {
		return companyRepo.findByCompanyCode(companycode);
	}

	public void deleteById(String companycode) {
		companyRepo.deleteById(companycode);
	}

}
