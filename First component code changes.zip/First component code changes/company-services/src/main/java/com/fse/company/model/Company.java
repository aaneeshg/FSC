package com.fse.company.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Company {

	@Id
	@Column(name = "companycode", unique = true, columnDefinition = "VARCHAR(64)")
	private String companyCode;
	@Column(name = "companyname")
	private String companyName;
	@Column(name = "companyceo")
	private String companyCEO;
	@Column(name = "companyturnover")
	private int companyTurnover;
	@Column(name = "companywebsite")
	private String companyWebsite;
	@Column(name = "companystockexchange")
	private String companyStockExchange;

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyCEO() {
		return companyCEO;
	}

	public void setCompanyCEO(String companyCEO) {
		this.companyCEO = companyCEO;
	}

	public int getCompanyTurnover() {
		return companyTurnover;
	}

	public void setCompanyTurnover(int companyTurnover) {
		this.companyTurnover = companyTurnover;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}

	public String getCompanyStockExchange() {
		return companyStockExchange;
	}

	public void setCompanyStockExchange(String companyStockExchange) {
		this.companyStockExchange = companyStockExchange;
	}

	@Override
	public String toString() {
		return "CompanyMdl [companyCode=" + companyCode + ", companyName=" + companyName + ", companyCEO=" + companyCEO
				+ ", companyTurnover=" + companyTurnover + ", companyWebsite=" + companyWebsite
				+ ", companyStockExchange=" + companyStockExchange + "]";
	}

}
